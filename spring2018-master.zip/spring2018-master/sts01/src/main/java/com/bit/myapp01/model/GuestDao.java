package com.bit.myapp01.model;

public interface GuestDao {
	void print();
}
