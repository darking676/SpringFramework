package com.bit.myapp01.model;

public class GuestDaoImpl implements GuestDao {

	@Override
	public void print() {
		System.out.println("DAO print() run...");
	}

}
